import{N as a}from"../chunks/vendor.1ea67431.js";export{a as start};
