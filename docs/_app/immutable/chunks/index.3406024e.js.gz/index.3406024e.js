import{w as s}from"./paths.a1d0f4da.js";const t=s(!1),o=s(""),e=s(""),n=s(0);export{o as a,t as i,e as l,n as z};
