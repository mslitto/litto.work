const t=s=>typeof s=="string";export{t as s};
